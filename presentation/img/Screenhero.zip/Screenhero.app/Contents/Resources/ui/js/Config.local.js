var browserNativeObject = new function () {
    var self = this;

    self.SessionType = { None: 0, Screen: 1, Voice: 2, Video: 3 };
    self.settings = {
        buddyThatIsMe: {
            email: "j@powwow.cc"
        },
        password: "test",
        shouldRememberPwd: true,
        isVoiceChatMutedOnScreenShare: false,
        shouldShowWelcomeView: false,
        isSlave: false, // set this to true to test incoming shares
        sessionType: self.SessionType.Screen
    };
    self.UpdateType = { None: 0, Minor: 1, Major: 2};

    // self.shouldUseNgrokServer = true; // whether to use the ngrok dev server for protobuf + api
    // self.launchWithSignup = true; // whether LoginView should show signup page
    // self.shouldShowWelcomeView = true; // show welcome view as if it's the user's first launch
    self.timeToSignIn = 100; // how long the cancel spinner is visible for
    self.timeToSignOut = 1000; // how long the server takes to disconnect and say we have disconnected
    self.timeToLoadBuddies = 100; // how long the buddy list takes to load
    self.timeToCreateAccount = 500; // how long the sign up spinner is visible for
    self.timeToSwitchPresenter = 1000; // how long switch presenter should take
    self.shouldEchoChatMessages = true; // whether we should echo chat messages
    self.timeToAcceptShare = 500; // how long a buddy takes to accept a share
    self.showIncomingShareInsteadOfChat = false; // hotwire the chat button to show incoming shares instead
    self.zoom = 1; // zoom level for DPI emulation
    self.setZoomDelay = 500; // time to delay set zoom call
    self.updateAvailable = self.UpdateType.None;
    // self.simulateNoBuddies = true; // like it says

    // Utils.shouldShowBorder = true; // set the mac border around the chrome
    // Utils.shouldBlockRightClick = false;

    this.OnLogin = function() {
        // self.LocalJSCall("ShowInvitation", [{name: "J Bond", email: "j@bond.com", bareJid:"j@bond.com", jid: "jid"}]);
        // self.LocalJSCall("ShowDialog", [{uuid: "UUID", tag: 0, title: "Screenhero is now in your status bar", body: "Buddies in the bar woohoo! 2/4", labelArray: ["OK", "Don't Hide"], defaultIndex: 0, shouldhideArray: [1, 0]}]);
        // self.LocalJSCall("ShowIncomingShare", ["J Sherwani"]);
        // self.LocalJSCall("ShowPopup", [{kind:"info", body:"Oh bloody hell!"}]);
        // self.LocalJSCall("ShowPopup", [{kind:"warning", body:"not again!";
        if (self.settings.isSlave)
            self.LocalJSCall("ShowIncomingShare", ["J Sherwani", self.settings.sessionType]);
        // self.LocalJSCall("ShowPopup", [{kind:"info", body:"Oh bloody hell!", timeout:0}]);
        // self.LocalJSCall("ShowPopup", [{kind:"success", body:"yay!", timeout:500}]);
        // self.LocalJSCall("ShowPopup", [{kind:"warning", body:"not again!"}]);
        // self.LocalJSCall("ShowPopup", [{kind:"warning", body:"There seem to something happening which is difficult to answer and we need to use this message for it.", timeout:2000}]);
        // BuddyListManager.ToggleShareWithBuddy("Faraz Khan");
        // BuddyList.ShowBusyDialog(Utils.buddyWithSanitizedProfilePic({name: "J Sherwani", bareJID: "J Sherwani");
        // self.LocalJSCall("UpdateUserStatus", [Main.loginStates.signedOut]);
        // self.LocalJSCall("UpdateUserStatusReason", [Main.loginErrors.networkError]);
    }

    this.CallNativeFunction = function(jsonStr) {
        var jsonrpc = jQuery.parseJSON(jsonStr);
        var method = eval("self." + jsonrpc.method);
        if (method)
            method.apply(this, jsonrpc.params);
        else
            console.log("Native->" + jsonrpc.method + "() not implemented in Config.local.js");
    }

    this.LocalJSCall = function(funcName, paramArray) {
        NativeToJSBridge.performJsonRpcWithSource(JSON.stringify(Utils.createJsonRpcObjectFromObject({method:funcName, params: paramArray, id: self.jsRpcID++})), NativeToJSBridge.SourceTypes.Native);
    }

    this.UpdateOptionsManager = function(updateObj) {
        for (var key in updateObj) {
            self.settings[key] = updateObj[key];
        }
    }

    this.LoadBuddies = function () {
        var buddies = [
                {name: "J Sherwani", email: "j@screenhero.com", bareJid: "J Sherwani", profilePicURL: "", isOnline: true, show: BuddyListManager.JabberStatusShow.DoNotDisturb},
                {name: "Don GoodmanWilson", email: "don@screenhero.com", bareJid: "Don GoodmanWilson", profilePicURL: "", isOnline: true, show: BuddyListManager.JabberStatusShow.Online},
                {name: "Jason DiCioccio", email: "jd@screenhero.com", bareJid: "Jason DiCioccio", profilePicURL: "", isOnline: false, show: BuddyListManager.JabberStatusShow.Online},
                {name: "ason DiCioccio", email: "JasonDiCioccio@screenhero.com", bareJid: "Jason DiCioccio2", profilePicURL: "BuddyList/buddy.jpg", isOnline: false, show: BuddyListManager.JabberStatusShow.Online},
                {name: "Faraz Khan", email: "faraz@screenhero.com", bareJid: "Faraz Khan", profilePicURL: "", isOnline: true, show: BuddyListManager.JabberStatusShow.Online},
                {name: "Don GoodmanWilson", email: "DonGoodmanWilson@screenhero.com", bareJid: "Don GoodmanWilson2", profilePicURL: "BuddyList/buddy.jpg", isOnline: false, show: BuddyListManager.JabberStatusShow.Online}
            ];
        if (self.simulateNoBuddies)
            self.LocalJSCall("ShowNoBuddiesView", []);
        else
            self.LocalJSCall("RefreshBuddyList", [buddies]);

        setTimeout(self.OnLogin, 1000);
    }

    this.SendChatMessageToBuddy = function (bareJid, msgTxt) {
        if (self.shouldEchoChatMessages)
            self.LocalJSCall("ReceivedChatMessageFromBuddy", [bareJid, "echo: " + msgTxt]);
    }

    this.DoXmppLogin = function () {
        self.LocalJSCall("UpdateUserStatus", [Main.loginStates.signingIn]);
        window.setTimeout(function () {
            if (self.settings.password != "error") {
                if (self.shouldShowWelcomeView)
                    self.LocalJSCall("ShowWelcomeView", []);
                self.LocalJSCall("UpdateUserStatus", [Main.loginStates.signedIn]);
                window.setTimeout(function() {
                    self.LoadBuddies();
                }, self.timeToLoadBuddies);
            }
            else {
                self.LocalJSCall("UpdateUserStatus", [Main.loginStates.signedOut]);
                self.LocalJSCall("UpdateUserStatusReason", [4]);
            }
        }, self.timeToSignIn);
    }

    this.CreateAccountWithInfo = function (name, email, password) {
        window.setTimeout(function () {
            if (password=="error")
                self.LocalJSCall("CreateAccountResponse", [false, "An error occurred."]);
            else {
                self.settings.nickname = name;
                self.settings.username = email;
                self.settings.password = password;
                self.LocalJSCall("CreateAccountResponse", [true]);
            }
        }, self.timeToCreateAccount);
    }

    this.ChangeUserStatus = function (newStatus) {
        setTimeout(function() {
            self.LocalJSCall("UpdateUserStatus", [newStatus]);
        }, self.timeToSignOut);
    }

    this.StartSessionWithBuddy = function (bareJid, sessionType) {
        self.settings.shareBuddyJid = bareJid;
        self.settings.sessionType = sessionType;
        self.LocalJSCall("SetPendingSharingBuddy", [bareJid]);
        setTimeout(function() { 
            self.LocalJSCall("SetSharingBuddy", [bareJid]);
        }, self.timeToAcceptShare);
    }

    this.StopShare = function () {
        self.LocalJSCall("SetSharingBuddy", []);
    }

    this.AcceptShareRequestFromBuddy = function (bareJid) {
        self.settings.shareBuddyJid = bareJid;
        self.LocalJSCall("SetSharingBuddy", [bareJid]);
        self.LocalJSCall("SessionDidStart", [self.settings.sessionType, false]);
    }

    this.RejectShareRequestFromBuddy = function (bareJid) {
        self.LocalJSCall("SetSharingBuddy", [null]);
    }

    this.LaunchUrlInBrowser = function(url) {
        window.open(url, "_blank");
    }

    this.StartChooseScreen = function() {
        setTimeout(function() {
            self.LocalJSCall("SessionDidStart", [self.settings.sessionType, true]);
        }, self.timeToSwitchPresenter);
    }

    this.SilentCheckForUpdates = function() {
        if (self.updateAvailable != self.UpdateType.None)
            self.LocalJSCall("UpdateAvailable", [self.updateAvailable == self.UpdateType.Major]);
    }

    this.SignalReadyForLaunch = function () {
        self.LocalJSCall("EnableDebugging", []);
        self.LocalJSCall("InitializeOptionsManager", [self.settings]);
        if (self.launchWithSignup)
            self.LocalJSCall("LaunchWithSignup", [self.settings.nickname, self.settings.username]);
        else
            self.LocalJSCall("LaunchWithSignIn", []);
    }

    self.jsRpcID = 0;
}

$(document).ready(function () {
    if (!Utils.isAwesomium) {
        var nativeObject = Utils.useWebNativeObject ? WebNativeObject : browserNativeObject;
        NativeToJSBridge.setNativeObject(nativeObject);
        if (Utils.shouldShowBorder) {
            $("body").css("background", "black");
            Utils.isAwesomiumMac = true;
        }
        setTimeout(function() {
            nativeObject.LocalJSCall("SetZoom", [browserNativeObject.zoom]);
        }, browserNativeObject.setZoomDelay);

        $(window).focus(function() {
            browserNativeObject.LocalJSCall("MainWindowActivated", [true]);
        });

        $(window).blur(function() {
            browserNativeObject.LocalJSCall("MainWindowActivated", [false]);
        });
    }
    if (browserNativeObject.shouldUseNgrokServer) {
        Utils.apiServerURI = "https://screenhero.ngrok.com";
        Utils.billingServerURI = "http://localhost:4000";
    }
});